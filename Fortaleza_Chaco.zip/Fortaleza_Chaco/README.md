# Fortaleza Chaco (AQUA CONTROL)

Aplicación de escritorio (Electron + PostgreSQL).

## Puesta en marcha
1. `npm install`
2. Copia `.env.example` a `.env` y completa los datos de PostgreSQL.
3. Crea la tabla con `database/schema.sql` (si aún no existe).
4. `npm start` — o doble clic en `scripts/iniciar.vbs` (Windows).

## Estructura
- `src/main/` — proceso principal: `main.js`, `preload.js`, `database.js`
- `src/renderer/` — scripts de las vistas (`login`, `panel_principal`, `usuarios`)
- `src/views/` — HTML
- `src/assets/` — CSS e imágenes
- `database/` — scripts SQL

## Notas de seguridad
- Las vistas no tienen acceso a Node; solo usan `window.api` (definido en `preload.js`).
- La gestión de usuarios exige rol Administrador en el proceso principal.
- Nunca subas `.env` al repositorio.
