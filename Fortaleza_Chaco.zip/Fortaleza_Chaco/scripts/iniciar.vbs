' Inicia la app sin ventana de consola. Funciona desde cualquier carpeta:
' toma como raíz la carpeta que contiene a "scripts".
Set fso = CreateObject("Scripting.FileSystemObject")
Set WshShell = CreateObject("WScript.Shell")
raiz = fso.GetParentFolderName(fso.GetParentFolderName(WScript.ScriptFullName))
WshShell.Run "cmd /c cd /d """ & raiz & """ && npm start", 0, False
