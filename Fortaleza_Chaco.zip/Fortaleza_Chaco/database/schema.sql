-- Tabla de usuarios (referencia). Ajusta si tu tabla ya existe con otros tipos.
CREATE TABLE IF NOT EXISTS usuarios (
  id_usuario          SERIAL PRIMARY KEY,
  nombre              VARCHAR(100) NOT NULL,
  apellido_primero    VARCHAR(100),
  apellido_secundario VARCHAR(100),
  celular             VARCHAR(20) UNIQUE,
  password            VARCHAR(255) NOT NULL,      -- hash bcrypt (60 caracteres)
  rol                 VARCHAR(30)  NOT NULL DEFAULT 'Operador',
  estado              VARCHAR(10)  NOT NULL DEFAULT 'ACTIVO'
                      CHECK (estado IN ('ACTIVO', 'INACTIVO'))
);
