// src/main/main.js
const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');

const {
  validarLogin,
  obtenerUsuarios,
  guardarUsuario,
  actualizarUsuario,
  cambiarEstadoUsuario,
  eliminarUsuario
} = require('./database');

// Evitar bloqueos de caché en Chromium
app.commandLine.appendSwitch('disable-gpu-shader-disk-cache');
app.commandLine.appendSwitch('disable-http-cache');

let mainWindow;
let usuarioSesion = null;

// ----------------------------------------------------
// Utilidades
// ----------------------------------------------------
const vista = (nombre) => path.join(__dirname, '../views', nombre);

function esAdmin() {
  return !!(usuarioSesion && String(usuarioSesion.rol || '').toUpperCase().startsWith('ADMIN'));
}

const SIN_PERMISO = { success: false, message: 'No tienes permisos para realizar esta acción.' };

// Límite de intentos de login: 5 fallos => bloqueo de 60 s por usuario
const intentos = new Map();
const MAX_INTENTOS = 5;
const BLOQUEO_MS = 60 * 1000;

function estaBloqueado(clave) {
  const r = intentos.get(clave);
  if (!r) return 0;
  if (r.hasta && r.hasta > Date.now()) return Math.ceil((r.hasta - Date.now()) / 1000);
  if (r.hasta && r.hasta <= Date.now()) intentos.delete(clave);
  return 0;
}

function registrarFallo(clave) {
  const r = intentos.get(clave) || { cuenta: 0, hasta: 0 };
  r.cuenta += 1;
  if (r.cuenta >= MAX_INTENTOS) {
    r.hasta = Date.now() + BLOQUEO_MS;
    r.cuenta = 0;
  }
  intentos.set(clave, r);
}

// ----------------------------------------------------
// Ventana
// ----------------------------------------------------
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    minWidth: 1000,
    minHeight: 700,
    frame: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true
    }
  });

  mainWindow.loadFile(vista('login.html'))
    .catch(err => console.error('❌ Error al cargar login.html:', err));

  mainWindow.on('closed', () => { mainWindow = null; });
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// ----------------------------------------------------
// IPC: sesión y navegación
// ----------------------------------------------------
ipcMain.handle('iniciar-sesion', async (event, datos) => {
  try {
    const clave = String(datos?.usuario || '').trim().toLowerCase();

    const espera = estaBloqueado(clave);
    if (espera) {
      return { success: false, message: `Demasiados intentos. Espera ${espera} s e inténtalo de nuevo.` };
    }

    // No se registran contraseñas en consola
    const respuesta = await validarLogin(datos?.usuario, datos?.password);

    if (!respuesta.success) {
      if (respuesta.credencialesInvalidas) registrarFallo(clave);
      return { success: false, message: respuesta.message };
    }

    intentos.delete(clave);
    usuarioSesion = respuesta.usuario;
    if (mainWindow) await mainWindow.loadFile(vista('panel_principal.html'));
    return { success: true };
  } catch (error) {
    console.error('❌ Error en el canal iniciar-sesion:', error);
    return { success: false, message: 'Error interno en la aplicación.' };
  }
});

ipcMain.handle('obtener-sesion', () => usuarioSesion);

ipcMain.on('navegar-a', (event, destino) => {
  if (!mainWindow) return;

  if (destino === 'login') {
    usuarioSesion = null;
    mainWindow.loadFile(vista('login.html')).catch(console.error);
  } else if (destino === 'dashboard' || destino === 'panel_principal') {
    if (!usuarioSesion) return mainWindow.loadFile(vista('login.html')).catch(console.error);
    mainWindow.loadFile(vista('panel_principal.html')).catch(console.error);
  }
});

// ----------------------------------------------------
// IPC: gestión de usuarios (solo Administrador)
// ----------------------------------------------------
ipcMain.handle('obtener-usuarios', async () => {
  if (!esAdmin()) return SIN_PERMISO;
  try {
    return await obtenerUsuarios();
  } catch (error) {
    console.error('❌ Error en IPC obtener-usuarios:', error);
    return { success: false, message: error.message };
  }
});

ipcMain.handle('guardar-usuario', async (event, usuario) => {
  if (!esAdmin()) return SIN_PERMISO;
  try {
    return await guardarUsuario(usuario);
  } catch (error) {
    console.error('❌ Error en IPC guardar-usuario:', error);
    return { success: false, message: error.message };
  }
});

ipcMain.handle('actualizar-usuario', async (event, usuario) => {
  if (!esAdmin()) return SIN_PERMISO;
  try {
    return await actualizarUsuario(usuario);
  } catch (error) {
    console.error('❌ Error en IPC actualizar-usuario:', error);
    return { success: false, message: error.message };
  }
});

ipcMain.handle('cambiar-estado-usuario', async (event, { id, nuevoEstado } = {}) => {
  if (!esAdmin()) return SIN_PERMISO;
  if (Number(id) === Number(usuarioSesion.id)) {
    return { success: false, message: 'No puedes cambiar el estado de tu propia cuenta.' };
  }
  try {
    return await cambiarEstadoUsuario(id, nuevoEstado);
  } catch (error) {
    console.error('❌ Error en IPC cambiar-estado-usuario:', error);
    return { success: false, message: error.message };
  }
});

ipcMain.handle('eliminar-usuario', async (event, idUsuario) => {
  if (!esAdmin()) return SIN_PERMISO;
  if (Number(idUsuario) === Number(usuarioSesion.id)) {
    return { success: false, message: 'No puedes eliminar tu propia cuenta.' };
  }
  try {
    return await eliminarUsuario(idUsuario);
  } catch (error) {
    console.error('❌ Error en IPC eliminar-usuario:', error);
    return { success: false, message: error.message };
  }
});

// ----------------------------------------------------
// IPC: control de ventana (barra personalizada)
// ----------------------------------------------------
ipcMain.on('window-control', (event, action) => {
  if (!mainWindow) return;
  if (action === 'minimize') mainWindow.minimize();
  if (action === 'maximize') {
    mainWindow.isMaximized() ? mainWindow.unmaximize() : mainWindow.maximize();
  }
  if (action === 'close') mainWindow.close();
});
