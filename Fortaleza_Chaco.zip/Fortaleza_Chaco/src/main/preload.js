// src/main/preload.js
// Puente seguro entre las vistas y el proceso principal.
// Las vistas SOLO pueden usar lo que se expone aquí (window.api).
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  // Sesión y navegación
  iniciarSesion: (datos) => ipcRenderer.invoke('iniciar-sesion', datos),
  obtenerSesion: () => ipcRenderer.invoke('obtener-sesion'),
  navegarA: (vista) => ipcRenderer.send('navegar-a', vista),
  controlVentana: (accion) => ipcRenderer.send('window-control', accion),

  // Gestión de usuarios
  usuarios: {
    obtener: () => ipcRenderer.invoke('obtener-usuarios'),
    guardar: (usuario) => ipcRenderer.invoke('guardar-usuario', usuario),
    actualizar: (usuario) => ipcRenderer.invoke('actualizar-usuario', usuario),
    cambiarEstado: (id, nuevoEstado) =>
      ipcRenderer.invoke('cambiar-estado-usuario', { id, nuevoEstado }),
    eliminar: (id) => ipcRenderer.invoke('eliminar-usuario', id)
  }
});
