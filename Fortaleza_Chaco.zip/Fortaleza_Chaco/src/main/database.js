// src/main/database.js
const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');

// ----------------------------------------------------
// Lectura simple del archivo .env (sin dependencias extra)
// ----------------------------------------------------
(function cargarEnv() {
  try {
    const ruta = path.join(__dirname, '../../.env');
    if (!fs.existsSync(ruta)) return;
    fs.readFileSync(ruta, 'utf8').split(/\r?\n/).forEach(linea => {
      const l = linea.trim();
      if (!l || l.startsWith('#')) return;
      const i = l.indexOf('=');
      if (i < 0) return;
      const k = l.slice(0, i).trim();
      const v = l.slice(i + 1).trim().replace(/^["']|["']$/g, '');
      if (!(k in process.env)) process.env[k] = v;
    });
  } catch (e) {
    console.error('⚠️ No se pudo leer .env:', e.message);
  }
})();

const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT) || 5432,
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME || 'inventario_chaco'
});

pool.connect((err, client, release) => {
  if (err) {
    console.error('❌ Error al conectar con PostgreSQL:', err.message);
  } else {
    console.log('✅ Conexión exitosa a la base de datos');
    release();
  }
});

// ----------------------------------------------------
// Utilidades
// ----------------------------------------------------
const ALFABETO = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

function generarPasswordAleatoria(longitud = 8) {
  let r = '';
  for (let i = 0; i < longitud; i++) r += ALFABETO[crypto.randomInt(ALFABETO.length)];
  return r;
}

const esHash = (p) => typeof p === 'string' && /^\$2[aby]\$/.test(p);

function iguales(a, b) {
  const A = Buffer.from(String(a));
  const B = Buffer.from(String(b));
  return A.length === B.length && crypto.timingSafeEqual(A, B);
}

const limpiar = (v) => (v ? String(v).trim() : null);

// ----------------------------------------------------
// 1. LOGIN (bcrypt; migra automáticamente claves en texto plano)
// ----------------------------------------------------
async function validarLogin(nombreIngresado, passwordIngresada) {
  const MSG_INVALIDO = 'Usuario o contraseña incorrectos.';
  try {
    const usuarioLimpio = nombreIngresado ? String(nombreIngresado).trim() : '';
    const passwordLimpia = passwordIngresada ? String(passwordIngresada).trim() : '';

    if (!usuarioLimpio || !passwordLimpia) {
      return { success: false, message: 'Ingresa tu usuario y contraseña.' };
    }

    const resultado = await pool.query(
      `SELECT id_usuario, nombre, apellido_primero, password, rol, estado
         FROM usuarios
        WHERE LOWER(nombre) = LOWER($1) OR celular = $1`,
      [usuarioLimpio]
    );

    // Puede haber varias coincidencias (mismo nombre): se prueba la clave en cada una
    for (const u of resultado.rows) {
      let ok = false;
      if (esHash(u.password)) {
        ok = await bcrypt.compare(passwordLimpia, u.password);
      } else if (u.password) {
        ok = iguales(u.password, passwordLimpia);
        if (ok) {
          // Migración: guardar el hash en lugar de la clave en texto plano
          const hash = await bcrypt.hash(passwordLimpia, 10);
          await pool.query('UPDATE usuarios SET password = $1 WHERE id_usuario = $2', [hash, u.id_usuario]);
        }
      }

      if (!ok) continue;

      if (u.estado !== 'ACTIVO') {
        return { success: false, message: 'El usuario se encuentra inactivo.' };
      }

      return {
        success: true,
        usuario: {
          id: u.id_usuario,
          nombre: `${u.nombre} ${u.apellido_primero || ''}`.trim(),
          rol: u.rol
        }
      };
    }

    return { success: false, message: MSG_INVALIDO, credencialesInvalidas: true };
  } catch (error) {
    console.error('❌ Error en la consulta SQL de login:', error.message);
    return { success: false, message: 'Error de conexión con la base de datos.' };
  }
}

// ----------------------------------------------------
// 2. OBTENER USUARIOS (nunca devuelve la contraseña)
// ----------------------------------------------------
async function obtenerUsuarios() {
  try {
    const resultado = await pool.query(
      `SELECT id_usuario, nombre, apellido_primero, apellido_secundario, celular, rol, estado
         FROM usuarios
        ORDER BY id_usuario DESC`
    );
    return { success: true, data: resultado.rows };
  } catch (error) {
    console.error('❌ Error al obtener los usuarios:', error.message);
    return { success: false, message: 'Error de conexión con la base de datos.' };
  }
}

// ----------------------------------------------------
// 3. GUARDAR USUARIO
// ----------------------------------------------------
async function guardarUsuario(usuario) {
  try {
    const { nombre, apellido_primero, apellido_secundario, celular, password, rol } = usuario || {};

    if (!limpiar(nombre)) return { success: false, message: 'El nombre es obligatorio.' };

    const passwordPlana = limpiar(password) || generarPasswordAleatoria(8);
    const passwordHash = await bcrypt.hash(passwordPlana, 10);

    const resultado = await pool.query(
      `INSERT INTO usuarios (nombre, apellido_primero, apellido_secundario, celular, password, rol, estado)
       VALUES ($1, $2, $3, $4, $5, $6, 'ACTIVO')
       RETURNING id_usuario, nombre, apellido_primero, rol, estado`,
      [
        limpiar(nombre),
        limpiar(apellido_primero),
        limpiar(apellido_secundario),
        limpiar(celular),
        passwordHash,
        limpiar(rol) || 'Operador'
      ]
    );

    return { success: true, data: resultado.rows[0], passwordGenerada: passwordPlana };
  } catch (error) {
    console.error('❌ Error al guardar usuario:', error.message);
    if (error.code === '23505') {
      return { success: false, message: 'El usuario o dato ya se encuentra registrado.' };
    }
    return { success: false, message: error.message };
  }
}

// ----------------------------------------------------
// 4. ACTUALIZAR USUARIO
//    - password con valor  -> se cambia la clave a esa
//    - regenerarPassword   -> se genera una clave nueva
//    - sin ninguno         -> se conserva la clave actual
// ----------------------------------------------------
async function actualizarUsuario(usuario) {
  try {
    const { id_usuario, nombre, apellido_primero, apellido_secundario, celular, rol, password, regenerarPassword } = usuario || {};

    if (!id_usuario) return { success: false, message: 'Falta el id del usuario.' };
    if (!limpiar(nombre)) return { success: false, message: 'El nombre es obligatorio.' };

    let passwordNueva = limpiar(password);
    let generada = false;
    if (!passwordNueva && regenerarPassword) {
      passwordNueva = generarPasswordAleatoria(8);
      generada = true;
    }

    const campos = [limpiar(nombre), limpiar(apellido_primero), limpiar(apellido_secundario), limpiar(celular), limpiar(rol) || 'Operador'];
    let query;
    let values;

    if (passwordNueva) {
      const hash = await bcrypt.hash(passwordNueva, 10);
      query = `UPDATE usuarios
                  SET nombre = $1, apellido_primero = $2, apellido_secundario = $3,
                      celular = $4, rol = $5, password = $6
                WHERE id_usuario = $7
            RETURNING id_usuario, nombre, rol`;
      values = [...campos, hash, id_usuario];
    } else {
      query = `UPDATE usuarios
                  SET nombre = $1, apellido_primero = $2, apellido_secundario = $3,
                      celular = $4, rol = $5
                WHERE id_usuario = $6
            RETURNING id_usuario, nombre, rol`;
      values = [...campos, id_usuario];
    }

    const resultado = await pool.query(query, values);

    if (resultado.rowCount === 0) {
      return { success: false, message: 'No se encontró el usuario a actualizar.' };
    }

    return {
      success: true,
      message: 'Usuario actualizado con éxito.',
      data: resultado.rows[0],
      passwordCambiada: !!passwordNueva,
      passwordGenerada: generada ? passwordNueva : null
    };
  } catch (error) {
    console.error('❌ Error al actualizar usuario:', error.message);
    if (error.code === '23505') {
      return { success: false, message: 'El número de celular o dato ya pertenece a otro usuario.' };
    }
    return { success: false, message: error.message };
  }
}

// ----------------------------------------------------
// 5. CAMBIAR ESTADO
// ----------------------------------------------------
async function cambiarEstadoUsuario(idUsuario, nuevoEstado) {
  try {
    if (!['ACTIVO', 'INACTIVO'].includes(nuevoEstado)) {
      return { success: false, message: 'Estado no válido.' };
    }
    const resultado = await pool.query(
      `UPDATE usuarios SET estado = $1 WHERE id_usuario = $2
       RETURNING id_usuario, nombre, estado`,
      [nuevoEstado, idUsuario]
    );
    if (resultado.rowCount === 0) {
      return { success: false, message: 'No se encontró el usuario para actualizar estado.' };
    }
    return { success: true, message: `Estado actualizado a ${nuevoEstado}.`, data: resultado.rows[0] };
  } catch (error) {
    console.error('❌ Error al cambiar estado del usuario:', error.message);
    return { success: false, message: error.message };
  }
}

// ----------------------------------------------------
// 6. ELIMINAR
// ----------------------------------------------------
async function eliminarUsuario(idUsuario) {
  try {
    const resultado = await pool.query('DELETE FROM usuarios WHERE id_usuario = $1', [idUsuario]);
    if (resultado.rowCount === 0) {
      return { success: false, message: 'No se encontró el usuario a eliminar.' };
    }
    return { success: true, message: 'Usuario eliminado permanentemente de la base de datos.' };
  } catch (error) {
    console.error('❌ Error al eliminar usuario:', error.message);
    if (error.code === '23503') {
      return {
        success: false,
        message: 'No se puede eliminar el usuario porque tiene registros asociados. Te recomendamos desactivarlo.'
      };
    }
    return { success: false, message: error.message };
  }
}

module.exports = {
  pool,
  validarLogin,
  obtenerUsuarios,
  guardarUsuario,
  actualizarUsuario,
  cambiarEstadoUsuario,
  eliminarUsuario
};
