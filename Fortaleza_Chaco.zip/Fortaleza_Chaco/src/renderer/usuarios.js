// src/renderer/usuarios.js
// ÚNICO dueño del formulario y la tabla de usuarios.
(() => {
  'use strict';

  const api = window.api.usuarios;
  let listaUsuarios = [];

  const $ = (id) => document.getElementById(id);

  // ---------- Utilidades ----------
  function generarPassword(longitud = 8) {
    const alfabeto = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const limite = 256 - (256 % alfabeto.length); // evita sesgo
    let r = '';
    while (r.length < longitud) {
      const bytes = crypto.getRandomValues(new Uint8Array(longitud));
      for (const b of bytes) {
        if (b < limite && r.length < longitud) r += alfabeto[b % alfabeto.length];
      }
    }
    return r;
  }

  function celda(texto, clase) {
    const td = document.createElement('td');
    td.textContent = texto;
    if (clase) td.className = clase;
    return td;
  }

  function boton(texto, clase, onClick) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'btn-accion ' + clase;
    b.textContent = texto;
    b.addEventListener('click', onClick);
    return b;
  }

  function mostrarPassword(password, nombre, titulo) {
    const mensaje =
      `${titulo}\n\n` +
      `Usuario: ${nombre}\n` +
      `🔑 Contraseña: ${password}\n\n` +
      'Guarda esta contraseña, no se volverá a mostrar.';
    navigator.clipboard.writeText(password)
      .then(() => alert(mensaje + '\n\n(Se copió al portapapeles)'))
      .catch(() => alert(mensaje));
  }

  // ---------- Tabla ----------
  async function cargarUsuarios() {
    try {
      const r = await api.obtener();
      if (!r || !r.success) {
        console.error('❌ Error desde DB:', r ? r.message : 'Sin respuesta');
        return;
      }
      listaUsuarios = r.data || [];
      filtrarUsuarios();
    } catch (err) {
      console.error('❌ Error al cargar usuarios:', err);
    }
  }

  function filtrarUsuarios() {
    const termino = ($('txtBuscarUsuario')?.value || '').toLowerCase().trim();
    const filtrados = !termino ? listaUsuarios : listaUsuarios.filter(u =>
      [u.nombre, u.apellido_primero, u.apellido_secundario, u.celular, u.rol]
        .some(v => v && String(v).toLowerCase().includes(termino))
    );
    renderizarTabla(filtrados);
  }

  function renderizarTabla(usuarios) {
    const tbody = $('tablaUsuarios');
    if (!tbody) return;
    tbody.replaceChildren();

    if (!usuarios.length) {
      const tr = document.createElement('tr');
      const td = celda('No se encontraron usuarios.');
      td.colSpan = 9;
      td.style.textAlign = 'center';
      tr.appendChild(td);
      tbody.appendChild(tr);
      return;
    }

    usuarios.forEach(u => {
      const activo = u.estado === 'ACTIVO';
      const nuevoEstado = activo ? 'INACTIVO' : 'ACTIVO';
      const nombreCompleto = [u.nombre, u.apellido_primero, u.apellido_secundario].filter(Boolean).join(' ');

      const tr = document.createElement('tr');
      tr.appendChild(celda('#' + u.id_usuario));
      tr.appendChild(celda(nombreCompleto));
      tr.appendChild(celda(u.apellido_primero || '-'));
      tr.appendChild(celda(u.apellido_secundario || '-'));
      tr.appendChild(celda(u.celular || 'S/N'));
      tr.appendChild(celda('********'));
      tr.appendChild(celda(u.rol || ''));

      const tdEstado = document.createElement('td');
      const badge = document.createElement('span');
      badge.className = 'badge ' + (activo ? 'badge-activo' : 'badge-inactivo');
      badge.textContent = u.estado || 'INACTIVO';
      tdEstado.appendChild(badge);
      tr.appendChild(tdEstado);

      const tdAcc = document.createElement('td');
      const cont = document.createElement('div');
      cont.className = 'acciones-usuario';
      cont.append(
        boton('✏️ Editar', 'editar', () => cargarEnFormulario(u)),
        boton(activo ? '⏸️ Desactivar' : '▶️ Activar', activo ? 'estado-off' : 'estado-on',
          () => cambiarEstado(u, nuevoEstado)),
        boton('🗑️ Eliminar', 'eliminar', () => eliminar(u))
      );
      tdAcc.appendChild(cont);
      tr.appendChild(tdAcc);

      tbody.appendChild(tr);
    });
  }

  // ---------- Acciones ----------
  async function cambiarEstado(u, nuevoEstado) {
    if (!confirm(`¿Cambiar el estado de "${u.nombre}" a ${nuevoEstado}?`)) return;
    const r = await api.cambiarEstado(u.id_usuario, nuevoEstado);
    if (r && r.success) cargarUsuarios();
    else alert('❌ Error al cambiar estado: ' + (r ? r.message : 'Error desconocido'));
  }

  async function eliminar(u) {
    if (!confirm(`¿Eliminar permanentemente a "${u.nombre}"? Esta acción no se puede deshacer.`)) return;
    const r = await api.eliminar(u.id_usuario);
    if (r && r.success) cargarUsuarios();
    else alert('❌ Error al eliminar: ' + (r ? r.message : 'Error desconocido'));
  }

  // ---------- Formulario ----------
  function btnGuardar() {
    return $('formUsuario')?.querySelector('button[type="submit"]');
  }

  function cargarEnFormulario(u) {
    $('txtIdUsuario').value = u.id_usuario;
    $('txtNombre').value = u.nombre || '';
    $('txtApellido1').value = u.apellido_primero || '';
    $('txtApellido2').value = u.apellido_secundario || '';
    $('txtCelular').value = u.celular || '';
    $('txtPassword').value = '';
    $('txtPassword').placeholder = 'Dejar en blanco para mantener la clave actual';
    $('txtPassword').required = false;

    // Selecciona el rol sin importar mayúsculas/minúsculas
    const select = $('selectRol');
    const op = [...select.options].find(o => o.value.toLowerCase() === String(u.rol || '').toLowerCase());
    if (op) select.value = op.value;

    const b = btnGuardar();
    if (b) {
      b.textContent = '💾 Actualizar Usuario';
      b.classList.add('modo-edicion');
    }

    if (!$('btnCancelarEdicion') && b) {
      const c = document.createElement('button');
      c.type = 'button';
      c.id = 'btnCancelarEdicion';
      c.className = 'btn-save btn-secundario';
      c.textContent = '✖ Cancelar';
      c.addEventListener('click', resetearFormulario);
      b.parentNode.appendChild(c);
    }

    $('formUsuario').scrollIntoView({ behavior: 'smooth' });
  }

  function resetearFormulario() {
    $('formUsuario').reset();
    $('txtIdUsuario').value = '';
    $('txtPassword').placeholder = 'Escribe o genera una clave';
    $('txtPassword').required = true;

    const b = btnGuardar();
    if (b) {
      b.textContent = 'Guardar Usuario';
      b.classList.remove('modo-edicion');
    }
    $('btnCancelarEdicion')?.remove();
  }

  async function manejarSubmit(e) {
    e.preventDefault();

    const id = $('txtIdUsuario').value;
    const datos = {
      nombre: $('txtNombre').value.trim(),
      apellido_primero: $('txtApellido1').value.trim(),
      apellido_secundario: $('txtApellido2').value.trim(),
      celular: $('txtCelular').value.trim(),
      rol: $('selectRol').value
    };
    const password = $('txtPassword').value.trim();

    if (!datos.nombre) { alert('⚠️ El nombre es obligatorio.'); return; }

    try {
      // ----- Edición -----
      if (id) {
        const r = await api.actualizar({ ...datos, id_usuario: id, password: password || null });
        if (r && r.success) {
          if (r.passwordCambiada) {
            mostrarPassword(r.passwordGenerada || password, datos.nombre, '✅ Usuario actualizado con nueva contraseña.');
          } else {
            alert('✅ Usuario actualizado correctamente.');
          }
          resetearFormulario();
          cargarUsuarios();
        } else {
          alert('❌ Error al actualizar: ' + (r ? r.message : 'Error desconocido'));
        }
        return;
      }

      // ----- Registro nuevo -----
      const r = await api.guardar({ ...datos, password: password || generarPassword(8) });
      if (r && r.success) {
        mostrarPassword(r.passwordGenerada, datos.nombre, '✅ Usuario guardado con éxito.');
        resetearFormulario();
        cargarUsuarios();
      } else {
        alert('❌ Error al guardar: ' + (r ? r.message : 'Error desconocido'));
      }
    } catch (err) {
      console.error('❌ Error de IPC:', err);
      alert('Ocurrió un error al procesar la solicitud.');
    }
  }

  // ---------- Inicio ----------
  document.addEventListener('DOMContentLoaded', () => {
    $('formUsuario')?.addEventListener('submit', manejarSubmit);
    $('txtBuscarUsuario')?.addEventListener('input', filtrarUsuarios);
    $('btnGenerarPass')?.addEventListener('click', (e) => {
      e.preventDefault();
      $('txtPassword').value = generarPassword(8);
    });

    // panel_principal.js avisa cuando se abre la vista de usuarios
    document.addEventListener('vista:usuarios', cargarUsuarios);
  });
})();
