// src/renderer/panel_principal.js
// Solo navegación entre vistas, cierre de sesión y datos de la sesión.
// La gestión de usuarios vive en usuarios.js.

document.addEventListener('DOMContentLoaded', async () => {
  const menuDashboard = document.getElementById('menuDashboard');
  const menuUsuarios = document.getElementById('menuUsuarios');
  const btnCerrarSesion = document.getElementById('btnCerrarSesion');

  const vistaDashboard = document.getElementById('vistaDashboard');
  const vistaUsuarios = document.getElementById('vistaUsuarios');
  const topbarTitulo = document.getElementById('topbarTitulo');

  function cambiarVista(vista) {
    const esDashboard = vista === 'dashboard';
    vistaDashboard?.classList.toggle('active', esDashboard);
    vistaUsuarios?.classList.toggle('active', !esDashboard);
    menuDashboard?.classList.toggle('active', esDashboard);
    menuUsuarios?.classList.toggle('active', !esDashboard);
    if (topbarTitulo) {
      topbarTitulo.textContent = esDashboard ? 'Panel Principal' : 'Gestión de Usuarios';
    }
    // usuarios.js escucha este evento y recarga la tabla
    if (!esDashboard) document.dispatchEvent(new CustomEvent('vista:usuarios'));
  }

  menuDashboard?.addEventListener('click', (e) => { e.preventDefault(); cambiarVista('dashboard'); });
  menuUsuarios?.addEventListener('click', (e) => { e.preventDefault(); cambiarVista('usuarios'); });
  btnCerrarSesion?.addEventListener('click', (e) => { e.preventDefault(); window.api.navegarA('login'); });

  // Datos del usuario en la barra superior; el menú Usuarios solo para administradores
  try {
    const sesion = await window.api.obtenerSesion();
    if (!sesion) { window.api.navegarA('login'); return; }

    const iniciales = sesion.nombre.split(/\s+/).map(p => p[0]).join('').slice(0, 2).toUpperCase();
    const avatar = document.querySelector('.user-profile .avatar');
    const nombre = document.querySelector('.user-profile .user-name');
    const rol = document.querySelector('.user-profile .user-role');

    if (avatar) avatar.textContent = iniciales;
    if (nombre?.firstChild) nombre.firstChild.textContent = sesion.nombre + ' ';
    if (rol) rol.textContent = sesion.rol || '';

    if (!String(sesion.rol || '').toUpperCase().startsWith('ADMIN')) {
      if (menuUsuarios) menuUsuarios.style.display = 'none';
    }
  } catch (err) {
    console.error('❌ Error al obtener la sesión:', err);
  }
});
