// src/renderer/login_efectos.js
// Efectos visuales del login: splash de entrada y burbujas de fondo.

window.addEventListener('load', () => {
  setTimeout(() => {
    const overlay = document.getElementById('splashOverlay');
    if (overlay) {
      overlay.classList.add('splash-hide');
      setTimeout(() => overlay.remove(), 850);
    }
  }, 1800);
});

// Si el logo no carga, oculta el splash de inmediato
document.getElementById('splashLogo')?.addEventListener('error', () => {
  document.getElementById('splashOverlay')?.remove();
});

// Generador de burbujas
const bubbleBox = document.getElementById('bubbles');
if (bubbleBox) {
  for (let i = 0; i < 20; i++) {
    const b = document.createElement('div');
    b.className = 'bubble';
    const size = 6 + Math.random() * 20;
    b.style.width = size + 'px';
    b.style.height = size + 'px';
    b.style.left = Math.random() * 100 + '%';
    b.style.animationDuration = (7 + Math.random() * 8) + 's';
    b.style.animationDelay = (Math.random() * 8) + 's';
    bubbleBox.appendChild(b);
  }
}
