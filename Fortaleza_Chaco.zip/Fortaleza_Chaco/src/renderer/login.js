// src/renderer/login.js
document.addEventListener('DOMContentLoaded', () => {
  const formLogin = document.getElementById('loginForm');
  const mensajeError = document.getElementById('mensajeError');

  if (!formLogin) return;

  formLogin.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (mensajeError) mensajeError.textContent = '';

    const usuario = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;

    try {
      const respuesta = await window.api.iniciarSesion({ usuario, password });

      // Si es correcto, el proceso principal carga el panel automáticamente
      if (!respuesta.success && mensajeError) {
        mensajeError.style.color = '#e63946';
        mensajeError.textContent = respuesta.message;
      }
    } catch (err) {
      console.error('Error IPC:', err);
      if (mensajeError) {
        mensajeError.style.color = '#e63946';
        mensajeError.textContent = 'Error al comunicarse con la aplicación.';
      }
    }
  });
});
